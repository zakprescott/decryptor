module.exports = {
    REGION: 'us-east-1',
    TABLE_NAME: 'decryptor-key-table'
}

